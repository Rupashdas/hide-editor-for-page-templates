=== Hide Editor for Page Templates ===
Contributors: rupash
Tags: Hide editor, Remove Editor, Remove post support
Requires at least: 4.1
Tested up to: 6.1.1
Requires PHP: 5.6
Stable tag: trunk
License: GPL v2
License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.en.html

A simple and nice plugin to hide classic editor or gutenberg editor from specific page templates.

== Description ==
A simple and nice plugin to hide classic editor or gutenberg from pre selected page templates. If the installation is okay, go to the settings > hide editor. If your current theme has pre-made page templates, you can select page templates where you want  to remove/hide editor. It\'s very easy to do.

== Installation ==
Installation is fairly straight forward. Install it from the WordPress plugin repository.
